const settings = {
  packname: 'Lucky Tech Hub Bot',
  author: '‎',
  botName: "L   T   H  Bot",
  botOwner: 'Lucky 218', // Your name
  ownerNumber: '25678XXXXXXX', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "👥public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "> ᴅᴇꜱᴄʀɪᴘᴛɪᴏɴ: ᴛʜɪꜱ ʙᴏᴛ ɪꜱ ꜰᴏʀ ᴍᴀɴᴀɢɪɴɢ ɢʀᴏᴜᴘ ᴄᴏᴍᴍᴀɴᴅꜱ ᴀɴᴅ ᴀᴜᴛᴏᴍᴀᴛɪɴɢ ᴛᴀꜱᴋꜱ.",
  caption: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʟᴜᴄᴋʏ ᴛᴇᴄʜ ʜᴜʙ",
  version: "2.2.6",
  prefix: ".",
  timezone: "Africa/Kampala", //put your country timeZone....leave blank if u don't know
  updateZipUrl: "https://www.mediafire.com/file/zlbozqwb014g68w/LuckyTechHub-Bot-main.zip/file",
};

module.exports = settings;
